<?php

require $_SERVER['DOCUMENT_ROOT'] . '/hospital/sidebars/' . 'sidebar_ADDDoctor.php';


$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>
<script>
.table-responsive {
   overflow-x: inherit;
}
</script>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin panel</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">

  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/jquery.dataTables.min.css">
   <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/sweetalert.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>
<script src="<?php echo $dept; ?>js/bootstrap-datetimepicker.min.js"></script>
<link href="<?php echo $dept; ?>js/bootstrap-datepicker.min.css" rel="stylesheet"/>

 <link rel="stylesheet" href="../viewerjs-master/dist/viewer.css">


  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Tariq Orthopedic</span>
    </a>

    <!-- Sidebar -->
<?php echo pagesidebar($dept); ?>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Doctors</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">

		<div class="row">
		          
	
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-info collapsed-card">
              <div class="card-header" data-widget="collapse" style=" cursor: pointer;">
                <h3 class="card-title">Add Doctor</h3>
				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">

                <div class="row">
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Doctor Name <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="doctorname" placeholder="Enter Doctor Name">
					
				  </div>
				   <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Doctor's Father Name  <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="fathername" placeholder="Enter Doctor's Father Name">
					
				  </div>
				  <div class="col-md-4">
				  <div class="form-group">
				  <label>Date of Birth  <b style="color:red;">*</b></label>
                   <div   class="input-group date" data-provide="datepicker">
					<input type="text" class="form-control" id="dob">
				<div class="input-group-addon">
				<span class="glyphicon glyphicon-th"></span>
				</div>
				</div>
				</div>
					
				  </div>
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Department Name  <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="deptname" placeholder="Enter Doctor's Department ">
					
				  </div>
				   <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Doctor's Designation  <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="desgname" placeholder="Enter Doctor's Designation ">
					
				  </div>
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Cell Number  <b style="color:red;">*</b></label>
                    <input type="number" class="form-control"  id="cellnum" placeholder="Enter Cell Number">
					
				  </div>
				   <div class="col-md-4">
				  
                    <label for="exampleInputEmail1" style="margin-top:-6px;"><br/>Cnic Number</label>
                    <input type="number" class="form-control" id="cnicnum" placeholder="Enter Doctor's cnic Number">
					
				  </div>
		
                </div>
				 
				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="inesertData();" class="btn btn-info">Submit</button>			  
				  
                </div>
            
            </div>


          </div>	
		  
		  </div>
		  
		  
		  <div class="row">
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">All Doctors</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
			  
      
                <div class="card-body">
				
				
                <div class="table-responsive">
                  <table id="table1" class="table m-0">
                    <thead>
                    <tr>
                      
                      <th>Name</th>
					  <th>Father Name</th>
					  <th>DOB</th>
					  <th>Department</th>
					  <th>Designation</th>
					  <th>Cell#</th>
					  <th>CNIC#</th>
					  <th>Action</th>
					  
                    </tr>
                    </thead>
                    <tbody id="doctors">

                    </tbody>
                  </table>
                </div>	
				  

				  

				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		  
		  </div>
	
	
	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Developed by Technodez <a href="http://technodez.com/">Technodez</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>


  <!-- /.control-sidebar -->
</div>
<!-- jQuery UI 1.11.4 -->
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/jquery-ui.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>



<script src="<?php echo $dept; ?>dist/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $dept; ?>pdfmake-master/build/pdfmake.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/vfs_fonts.js"></script>
<script src="<?php echo $dept; ?>dist/js/buttons.html5.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/buttons.print.min.js"></script>
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/moment.min.js"></script>
<script src="<?php echo $dept; ?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<script src="../viewerjs-master/dist/viewer.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->


 

<script>


var dateObj = new Date();
var month = dateObj.getUTCMonth() + 1; //months from 1-12
var day = dateObj.getUTCDate();
var year = dateObj.getUTCFullYear();

newdate = month + "/" + day + "/" + year;
document.getElementById("dob").value = newdate;
var check=0;
function checkFilled() {
	var out=0;
    var input = document.querySelectorAll('input')
    for (var i = 0;i < input.length-1; i++) {
    if (input[i].value == '') {
        input[i].style.borderColor = 'red';
		out=1;
    } 
    }
	return out;
}
	



function inesertData() {

var ch=checkFilled();
if(ch == 1)
{
	swal({
  title: "Error",
  text: "Please Fill all Required Fields",
  icon: "error",
 
   showConfirmButton:false,
  confirmButtonText: 'ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		

	  
 
  } 
});
	

}
	
else
{
	
		
		$.post("controller.php", {
			
			
			doctorname : $("#doctorname").val(),
			fathername : $("#fathername").val(),
			dob : $("#dob").val(),
			deptname : $("#deptname").val(),
			desgname : $("#desgname").val(),
			cellnum : $("#cellnum").val(),
			cnicnum : $("#cnicnum").val(),
			
			
			
			action : 'adddoctor'
			
		}, function(result) {

			
	
swal({
  title: "Success",
  text: "Doctor Added Successfully",
  icon: "success",
 
   showConfirmButton:false,
  confirmButtonText: 'Ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		
location.reload();		

	  
 
  } 
});
	
			
			
			
		});
}		
		
	}

	
	
	
$.post("controller.php", {
	
	
	action : 'getdoctors'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {



                    var temp = '<tr >';
                    
					  
                      temp +='<td style="height: px;">'+fres['Name'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['Father_Name'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['DOB'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['Department'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['Designation'][i]+'</td>';
					    temp +='<td style="height: px;">'+fres['Cell_Number'][i]+'</td>';
						 temp +='<td style="height: px;">'+fres['CNIC_Number'][i]+'</td>';
					 
					  temp +='<td style="height: 10px;"><button onclick="updatedoctor('+fres['id'][i]+');" type="button" title="Update Category" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deletedoctor('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    temp +='</tr>';	
		
		  $('#doctors').append(temp);
		  

	
		
	}	
	
$('#table1').DataTable( {} );	


	
});		
	

function deletedoctor(delid)
{
	
swal({
  title: "Are you sure?",
  text: "Delete Item permanently",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  $.post("controller.php", {
	
	delid : delid,
	
	action : 'deletedoctor'
	
}, function(result) {
		
	location.reload();
});		

	  
 
  } 
});
	


}

function updatedoctor(upid)
{
	window.location.href = "updatedoctor.php?upid="+upid;	


}	

	
	

</script>





</body>
</html>

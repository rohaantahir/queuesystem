<?php

require $_SERVER['DOCUMENT_ROOT'] . '/Hospital/sidebars/' . 'sidebar_viewtest.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Datewise Reports</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
   <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/sweetalert.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->

  
  <!-- Google Font: Source Sans Pro -->
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>

 <link rel="stylesheet" href="../viewerjs-master/dist/viewer.css">
  <!-- Font Awesome -->
  
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/daterangepicker/daterangepicker-bs3.css">
  <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css"/>
  <!-- Ionicons -->
  

  
  <!-- Theme style -->
  <!-- iCheck -->

  <!-- Google Font: Source Sans Pro -->

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Tariq Orthopedic</span>
    </a>

    <!-- Sidebar -->

	<?php echo pagesidebar($dept); ?>
	
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Reports</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      
        <!-- Small boxes (Stat box) -->
		
		<div class="row">
          <div class="col-md-6">
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Select Date</h3>
              </div>
              <div class="card-body">
                <!-- Date range -->
                <div class="form-group">
                  <label>Date range:</label>

                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-calendar"></i>
                      </span>
                    </div>
                    <input type="text" class="form-control float-right" id="reservation">
                  </div>
                  <!-- /.input group -->
                </div>


              </div>
			 
                <div class="card-footer">
                  <button onclick="getreports();" class="btn btn-info">Search</button>			  
				  
                </div>			 
			  
              <!-- /.card-body -->
            </div>

          </div>
		  </div>
		  
		
		
		
		<div class="row">
		
               <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-info">
             
				    <div class="card">
            <div class="card-header">
              <h3 class="card-title">All Tests</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="table1" class="table table-bordered table-striped">
                <thead>
               <tr>
                      
                      <th >Name</th>
					  <th>Father Name</th>
					  <th>Age</th>
					  <th>Gender</th>
					  <th>Date</th>
					  <th>Doctor</th>
					  <th>Test Type</th>
					  <th>Lab Incharge</th>
					  
					  <th>Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="tests">

                 </tbody>
               
              </table>
            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>
</div>		  


		  
		  
		  
		  
 		  
		  
		  



		  
		
		
          <!-- ./col -->
        
        <!-- /.row -->
        <!-- Main row -->

        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Developed by Technodez <a href="http://technodez.com/">Technodez</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

<script type="text/javascript" src="../DataTables/datatables.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/dataTables.buttons.min.js"></script>

<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="<?php echo $dept; ?>dist/js/moment.min.js"></script>
<script src="<?php echo $dept; ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../viewerjs-master/dist/viewer.js"></script>
<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>

<!-- AdminLTE for demo purposes -->


<script>
function FetchData() {
		
$("#table1").dataTable().fnDestroy();		

$('#tests').empty();
		




$.post("controller.php", {

	
	
	action : 'getdailytickets'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);
	
	
	for (var i = 0; i < fres['id'].length; i++) {

				
				imagename=fres['status'][i];
					var ret = imagename.replace('.jpg','');

                    var temp = '<tr>';
                    
					 temp +='<td style="width:250px;font-size: 100%;">'+fres['id'][i]+'</td>';
					   temp +='<td style="width:400px;font-size: 100%;">'+fres['status'][i]+'</td>';
					   temp +='<td style="width:50px;font-size: 100%;">'+fres['status'][i]+'</td>';
					   	 temp +='<td style="width:50px;font-size: 100%;">'+fres['status'][i]+'</td>';
					   temp +='<td style="width:150px;font-size: 100%;">'+fres['status'][i]+'</td>';
					   temp +='<td style="width:250px;font-size: 100%;">'+fres['status'][i]+'</td>';
					    temp +='<td style="width:400px;font-size: 100%;">'+fres['status'][i]+'</td>';
						 temp +='<td style="width:300px;font-size: 100%;">'+fres['status'][i]+'</td>';
					 
					  temp +='<td style="width:100px;"> <button onclick="check('+ret+');" type="button" title="Update Test" class="btn btn-sm btn-info "><i class="fa fa-eye"></i></button> <button onclick="deletetest('+fres['id'][i]+');" type="button" title="Delete Test" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button>  </td>';

                    temp +='</tr>';	
		
		  $('#tests').append(temp);

	
		
	}
	

	
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
      
	"ordering": true,
	"columnDefs": [{
        "targets": [5,7],
        "searchable": false
    }]
    } );
} );	
	

	
});	
	
}setTimeout(FetchData,1000);



$('#reservation').daterangepicker();
function check(images)
{
	images=images+'.jpg';
	picshow(images);
}

function picshow(imagename)
{
		
		var foder='testimages/';
		var res = foder.concat(imagename);

		var image = new Image();

        image.src = res;

        var viewer = new Viewer(image, {
          hidden: function () {
            viewer.destroy();
          },
        });

        // image.click();
        viewer.show();
}



function getreports()
{
	
$("#table1").dataTable().fnDestroy();		

$('#tests').empty();
		

	
	
var datestr = $('#reservation').val();
var dateObj = new Date();
var month = dateObj.getUTCMonth() + 1; //months from 1-12
var day = dateObj.getUTCDate();
var year = dateObj.getUTCFullYear();

newdate = month + "/" + day + "/" + year;


var res = datestr.split("-");



$.post("controller.php", {

	
	startdate : res[0],
	
	enddate : res[1],
	
	action : 'getreports'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);
	
	
	for (var i = 0; i < fres['id'].length; i++) {

				
				imagename=fres['picture'][i];
					var ret = imagename.replace('.jpg','');

                    var temp = '<tr>';
                    
					 temp +='<td style="width:250px;font-size: 100%;">'+fres['Patient_Name'][i]+'</td>';
					   temp +='<td style="width:400px;font-size: 100%;">'+fres['Father_Name'][i]+'</td>';
					   temp +='<td style="width:50px;font-size: 100%;">'+fres['Age'][i]+'</td>';
					   	 temp +='<td style="width:50px;font-size: 100%;">'+fres['gender'][i]+'</td>';
					   temp +='<td style="width:150px;font-size: 100%;">'+fres['Date'][i]+'</td>';
					   temp +='<td style="width:250px;font-size: 100%;">'+fres['Doctor'][i]+'</td>';
					    temp +='<td style="width:400px;font-size: 100%;">'+fres['TestType'][i]+'</td>';
						 temp +='<td style="width:300px;font-size: 100%;">'+fres['Lab_Incharge'][i]+'</td>';
					 
					  temp +='<td style="width:100px;"> <button onclick="check('+ret+');" type="button" title="Update Test" class="btn btn-sm btn-info "><i class="fa fa-eye"></i></button> <button onclick="deletetest('+fres['id'][i]+');" type="button" title="Delete Test" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button>  </td>';

                    temp +='</tr>';	
		
		  $('#tests').append(temp);

	
		
	}
	
var dateObj = new Date();
var month = dateObj.getUTCMonth() + 1; //months from 1-12
var day = dateObj.getUTCDate();
var year = dateObj.getUTCFullYear();

newdate = month + "/" + day + "/" + year;
	
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
            buttons: [{
      extend: 'pdfHtml5',
      //message: "Made: 20_05-17\nMade by whom: User232\n" + "Custom message",
      title: 'Test Report',
      header: true,
      customize: function(doc) {
        doc.content.splice(0, 1, {
          text: [{
            text: 'Dated: '+newdate+'\n',
            bold: true,
            fontSize: 16
          }, {
            text: ' Generated by Admin \n',
            bold: true,
            fontSize: 11
          }, {
            text: 'All Tests',
            bold: true,
            fontSize: 11
          }],
          margin: [0, 0, 0, 12],
          alignment: 'center'
        });
      }
    }],
	"ordering": true,
	"columnDefs": [{
        "targets": [5,7],
        "searchable": false
    }]
    } );
} );	
	

	
});	


}




</script>


</body>
</html>

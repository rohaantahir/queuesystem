<?php

require $_SERVER['DOCUMENT_ROOT'] . '/hospital/sidebars/' . 'sidebar_ADDTest.php';


$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Test Type</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">

    <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css"/>

  
  <!-- Google Font: Source Sans Pro -->
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Tariq Orthopedic</span>
    </a>

    <!-- Sidebar -->
<?php echo pagesidebar($dept); ?>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">X-Ray TESTS</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">

		<div class="row">
	
          <div class="col-md-10">
            <!-- general form elements -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Add New Test Type</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">
				
				

				  

				  
				 
				 
				  
				  
                <div class="row">
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Test Name</label>
                    <input type="text" class="form-control" style="text-transform: capitalize;" id="testtype" placeholder="Enter Test Name">
					
				  </div>
				  
				  
			 		  
				  			  
				  

                </div>
				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="inesertData();" class="btn btn-info">Submit</button>			  
				  
                </div>
            
            </div>


          </div>	
		  
		  </div>
		  
		  
		  <div class="row">
          <div class="col-md-10">
            <!-- general form elements -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">All Test Types</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
			  
      
                <div class="card-body">
				
				
                <div class="table-responsive">
                  <table id="table1" class="table m-0">
                    <thead>
                    <tr>
                      
                      <th>Test NAme</th>
					  <th>Action</th>
					  
                    </tr>
                    </thead>
                    <tbody id="categories">

                    </tbody>
                  </table>
                </div>	
				  

				  

				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		  
		  </div>
	
	
	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2018 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.0-alpha
    </div>
  </footer>


  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo $dept; ?>dist/js/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

<script type="text/javascript" src="../DataTables/datatables.min.js"></script>


<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>



<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="<?php echo $dept; ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<!-- AdminLTE for demo purposes -->

<script>
$(function() {
  $("#testtype").focus();
});


function checkFilled() {
	var out=0;
    var input = document.querySelectorAll('input')
    for (var i = 0;i < input.length-1; i++) {
    if (input[i].value == '') {
        input[i].style.borderColor = 'red';
		out=1;
    } 
    }
	return out;
}

function inesertData() {
var ch=checkFilled();
if(ch == 1)
{
	swal({
  title: "Error",
  text: "Please Fill all Required Fields",
  icon: "error",
 
   showConfirmButton:false,
  confirmButtonText: 'ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		

	  
 
  } 
});
	

}
	
else
{	
		
		$.post("controller.php", {
			
			
			testtype : $("#testtype").val(),
			
			
			action : 'addtesttype'
			
		}, function(result) {
			
	
	swal({
  title: "Success",
  text: "New Test Type Added!",
  icon: "success",
 
   showConfirmButton:false,
  confirmButtonText: 'ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		location.reload();

	  
 
  } 
});
			
			
			
		});
			
		
	}
}


	
	
	
$.post("controller.php", {
	
	
	action : 'getcategories'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {



                    var temp = '<tr >';
                    
					  
                      temp +='<td style="height: px;"><b>'+fres['TestType'][i]+'</b></td>';
					 
					  temp +='<td style="height: 10px;"><button onclick="updatecategory('+fres['id'][i]+');" type="button" title="Update Category" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deletecategory('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    temp +='</tr>';	
		
		  $('#categories').append(temp);

	
		
	}	
	
$('#table1').DataTable( {} );	


	
});		
	

function deletecategory(delid)
{
	
swal({
  title: "Are you sure?",
  text: "Delete Item permanently",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  $.post("controller.php", {
	
	delid : delid,
	
	action : 'deletesttype'
	
}, function(result) {
		
	window.location.href = "testtype.php";
});		

	  
 
  } 
});
	


}

function updatecategory(upid)
{
	window.location.href = "updatetesttype.php?upid="+upid;	


}	

	
	

</script>





</body>
</html>

<?php

require $_SERVER['DOCUMENT_ROOT'] . '/hospital/sidebars/' . 'sidebar_ADDDoctor.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Update Doctor</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">

  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css">    
  
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
   <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Tariq Orthopedic</span>
    </a>
    <!-- Sidebar -->
<?php echo pagesidebar($dept); ?>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Update Doctor</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">

		<div class="row">
	
          <div class="col-md-10">
            <!-- general form elements -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Update Doctor</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">
				<div class="row">
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Doctor Name <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="doctorname" placeholder="Enter Doctor Name">
					
				  </div>
				   <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Doctor's Father Name  <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="fathername" placeholder="Enter Doctor's Father Name">
					
				  </div>
				  <div class="col-md-4">
				  <div class="form-group">
				  <label>Date of Birth  <b style="color:red;">*</b></label>
                   <div   class="input-group date" data-provide="datepicker">
					<input type="text" class="form-control" id="dob">
				<div class="input-group-addon">
				<span class="glyphicon glyphicon-th"></span>
				</div>
				</div>
				</div>
					
				  </div>
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Department Name  <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="deptname" placeholder="Enter Doctor's Department ">
					
				  </div>
				   <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Doctor's Designation  <b style="color:red;">*</b></label>
                    <input type="text" class="form-control" id="desgname" placeholder="Enter Doctor's Designation ">
					
				  </div>
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Cell Number  <b style="color:red;">*</b></label>
                    <input type="number" class="form-control"  id="cellnum" placeholder="Enter Cell Number">
					
				  </div>
				   <div class="col-md-4">
				  
                    <label for="exampleInputEmail1" style="margin-top:-6px;"><br/>Cnic Number</label>
                    <input type="number" class="form-control" id="cnicnum" placeholder="Enter Doctor's cnic Number">
					
				  </div>
		
                </div>
				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="updatedoctor();" class="btn btn-info">Update</button>			  
				  
                </div>
            
            </div>


          </div>	
		  
		  </div>
	
	
	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2018 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.0-alpha
    </div>
  </footer>


  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>



<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="<?php echo $dept; ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<!-- AdminLTE for demo purposes -->

<script>		
	

$.post("controller.php", {
	
	
	catid : <?php echo $_REQUEST['upid']; ?>,
	action : 'getdoctor'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['Name'].length; i++) {
		
		$("#doctorname").val(fres['Name'][i]);
		$("#fathername").val(fres['Father_Name'][i]);
		$("#dob").val(fres['DOB'][i]);
		$("#deptname").val(fres['Department'][i]);
		$("#desgname").val(fres['Designation'][i]);
		$("#cellnum").val(fres['Cell_Number'][i]);
		$("#cnicnum").val(fres['CNIC_Number'][i]);

	
		
	}	
	
});	
	
	
	
	

function updatedoctor()
{
	
$.post("controller.php", {
	
	catid : <?php echo $_REQUEST['upid']; ?>,
	Name : $("#doctorname").val(),
	Father_Name : $("#fathername").val(),
	DOB : $("#dob").val(),
	Department : $("#deptname").val(),
	Designation : $("#desgname").val(),
	Cell_Number : $("#cellnum").val(),
	CNIC_Number : $("#cnicnum").val(),
	
	action : 'updatedoctor'
	
}, function(result) {
	
		swal({
  title: "Success",
  text: "Doctor Added Successfully",
  icon: "success",
 
   showConfirmButton:false,
  confirmButtonText: 'Ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		
window.location.href = "doctor.php";		

	  
 
  } 
});

	
	
});		


}
	

	
	

</script>





</body>
</html>

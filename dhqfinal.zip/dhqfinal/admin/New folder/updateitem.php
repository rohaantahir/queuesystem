<?php

require $_SERVER['DOCUMENT_ROOT'] . '/Hospital/' . 'sidebars/adminsidebarandheader.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin panel</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">


  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Tariq Orthopedic</span>
    </a>

    <!-- Sidebar -->
<?php echo pagesidebar($dept); ?>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Update Item</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">

          <div class="col-md-10">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Item Details</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">
				
				

				  

				  
				 
				 
				  
				  
                <div class="row">
				  <div class="col-md-4">
				  
                    <label for="exampleInputEmail1">Item Name</label>
                    <input type="text" class="form-control" id="itemname" placeholder="Enter Item Name">
					
				  </div>
				  
				  
				  <div class="col-md-2">
				  
                    <label for="exampleInputEmail1">Quantity</label>
                    <input type="number" class="form-control" id="itemquantity" placeholder="Enter quantity">
					
				  </div>
				  
				  <div class="col-md-2">
				  
                    <label for="exampleInputEmail1">Price</label>
                    <input type="number" class="form-control" id="itemprice" placeholder="Enter Price">
					
				  </div>


			  <div class="col-md-4">
			  
                  <div class="form-group">
                    <label for="file">Select Item Image</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="file">
                        <label class="custom-file-label" for="file">Choose file</label>
                      </div>
                      <div class="input-group-append">
                      </div>
                    </div>
                  </div>

				</div>				  
				  

                </div>
				
				<br/>

				<div class="row">
					
				  <div class="col-md-6">
				  
					<label>Item Description</label>
                    <textarea class="form-control" id="itemdescription" rows="3" placeholder="Enter Descrition of Item"></textarea>
					
				  </div>              
			  
			  
				  			  
				</div>  
				  
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="updateData();" class="btn btn-primary">Submit</button>			  
				  
                </div>
            
            </div>
            <!-- /.card -->

            <!-- Form Element sizes -->

            <!-- /.card -->

            <!-- /.card -->

            <!-- Input addon -->

            <!-- /.card -->

          </div>	
	
<input type="hidden" id="itempic">	
	
	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2018 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.0-alpha
    </div>
  </footer>


  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>

<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<!-- AdminLTE for demo purposes -->

<script>

$.post("controller.php", {
	
	itemid : <?php echo $_REQUEST['upid']; ?>,
	
	action : 'getitemdetails'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['itemid'].length; i++) {
		
		$('#itemname').val(fres['itemname'][i]);
		$('#itemquantity').val(fres['itemquantity'][i]);
		$('#itemprice').val(fres['itemprice'][i]);
		$('#itemdescription').val(fres['itemdescription'][i]);
		$('#itempic').val(fres['pic'][i]);
		
	}
	

	
});



function inesertData() {	
		
		$.post("controller.php", {
			
			
			itemname : $("#itemname").val(),
			itemquantity : $("#itemquantity").val(),
			itemprice : $("#itemprice").val(),
			itemdescription : $("#itemdescription").val(),
			
			
			action : 'writedata'
			
		}, function(result) {
			
		
  var input = document.getElementById("file");
  file = input.files[0];
  if(file != undefined){
    formData= new FormData();
    if(!!file.type.match(/image.*/)){
      formData.append("image", file);
	  formData.append("itemid", result);
      $.ajax({
        url: "upload.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(data){
            alert('success');
        }
      });
    }else{
      alert('Not a valid image!');
    }
  }else{
    alert('Input something!');
  }			
			
			
			
		});
			
		
	}
	
	
function updateData()
{
	
		$.post("controller.php", {
			
			itemid : <?php echo $_REQUEST['upid']; ?>, 
			itemname : $("#itemname").val(),
			itemquantity : $("#itemquantity").val(),
			itemprice : $("#itemprice").val(),
			itemdescription : $("#itemdescription").val(),
			itempic : $("#itempic").val(),
			
			
			action : 'updatedata'
			
		}, function(result) {
				
			var input = document.getElementById("file");
			file = input.files[0];
			if(file != undefined){
				
				alert("Data Updated");

  var input = document.getElementById("file");
  file = input.files[0];
  if(file != undefined){
    formData= new FormData();
    if(!!file.type.match(/image.*/)){
      formData.append("image", file);
	  formData.append("itemid", result);
      $.ajax({
        url: "updateupload.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(data){
           
        }
      });
    }else{
      alert('Not a valid image!');
    }
  }else{
    alert('Input something!');
  }	
				

			}
				
			else{

				
setTimeout(function () { 
swal({
  title: "Data Updated!",
  text: "Your data has been updated.!",
  type: "success",
  confirmButtonText: "OK"
},
function(isConfirm){
  if (isConfirm) {
	window.location.href = "index.php";
  }
}); }, 1000);
			
			}			
				
				
			
			
		});	
	

}	

	

	
	

</script>





</body>
</html>

<?php

require $_SERVER['DOCUMENT_ROOT'] . '/hospital/sidebars/' . 'sidebar_ADD.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Update Test</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">

   <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/sweetalert.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>
<script src="<?php echo $dept; ?>js/bootstrap-datetimepicker.min.js"></script>
<link href="<?php echo $dept; ?>js/bootstrap-datepicker.min.css" rel="stylesheet"/>

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Tariq Orthopedic</span>
    </a>

    <!-- Sidebar -->
<?php echo pagesidebar($dept); ?>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"> Update Test</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">

		<div class="row">
	
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Add New Test</h3>
				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">
				
				

				  

				  
				 
				 
				  
				  
                <div class="row">
				  <div class="col-md-3">
				  
                    <label for="exampleInputEmail1">Patient Name</label>
                    <input type="text" class="form-control" id="patientname" placeholder="Enter Patient's Name"/>
					<input type="text" class="form-control" id="adminname" placeholder="Enter Patient's Name"/>
					<input type="text" class="form-control" id="Incharge_ID" placeholder="Enter Patient's Name"/>
					<input type="text" class="form-control" id="picture" placeholder="Enter Patient's Name"/>
					<input type="text" class="form-control" id="getdoctor" placeholder="Enter Patient's Name"/>
					<input type="text" class="form-control" id="gettesttype" placeholder="Enter Patient's Name"/>
					
				  </div>
				  <div class="col-md-3">
				  
                    <label for="exampleInputEmail1">Patient's Father Name</label>
                    <input type="text" class="form-control" id="Pfather" placeholder="Enter Patient's Father Name">
					
				  </div>
				  <div class="col-md-6">
				  <div class="row">
				  <div class="col-md-6">
                   <div class="form-group">
                    <label>Gender</label>
                    <select class="form-control" id="gender">
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                   
                    </select>
                  </div>
				  
				  </div>
				  <div class="col-md-6">
                   <div class="form-group">
                    <label for="exampleInputEmail1">Patient's Age</label>
                    <input type="number" class="form-control" id="age" placeholder="Enter Age">
                  </div>
				  
				  </div>
				  </div >
				  
				 
				  
					
				  </div>
				  <div class="col-md-3">
				  <div class="form-group">
				  <label>Date</label>
                   <div   class="input-group date" data-provide="datepicker">
					<input type="text" class="form-control" id="mydate">
				<div class="input-group-addon">
				<span class="glyphicon glyphicon-th"></span>
				</div>
				</div>
				</div>
					
				  </div>
				  <div class="col-md-3">
				  <div class="row">
				  <div class="col-md-10">
					<div class="form-group">
						<label>Select Doctor</label>
						<select class="form-control" id="doctor">
						<option value="0" selected disabled></option>	
						<option value="banana">Banana</option>
						
						
						</select>
					</div><!-- /.form-group -->
					</div>
					<div class="col-md-2">
					<div class="form-group">
					<label></br></label>
						<a  href="doctor.php" class="btn btn-default" style="margin-right:40px;"><i class="fa fa-plus nav-icon"></i></a>		

						
					</div><!-- /.form-group -->
					</div>
				</div>
				</div>	
				
				  <div class="col-md-3">
				  <div class="row">
				   <div class="col-md-10">
					<div class="form-group">
						<label>Select Test Type</label>
						<select class="form-control "  id="category">
						<option value="0" selected disabled></option>										
						
						</select>

						
					</div><!-- /.form-group -->
					</div>
				<div class="col-md-2">
					<div class="form-group">
					<label></br></label>
						 <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus nav-icon"></i></button>
						
					</div><!-- /.form-group -->
					</div>
					</div>
				</div>	
				  
				  
			  <div class="col-md-3">
			  
                  <div class="form-group">
                    <label for="file">Select X-Ray Image</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="file">
                        <label class="custom-file-label" for="file" id="fileLabel">Choose file</label>
                      </div>
                      <div class="input-group-append">
                      </div>
                    </div>
                  </div>

				</div>				  
				  			  
				  

                </div>
				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="updatetest();" class="btn btn-info">Submit</button>			  
				  
                </div>
            
            </div>


          </div>	
		  
		  </div>

	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2018 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.0-alpha
    </div>
  </footer>


  <!-- /.control-sidebar -->
</div>
<!-- Bootstrap 4 -->

<!-- DataTables -->

<!-- SlimScroll -->
<!-- ./wrapper -->
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo $dept; ?>dist/js/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->



<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>



<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="<?php echo $dept; ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<!-- AdminLTE for demo purposes -->



<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="<?php echo $dept; ?>plugins/daterangepicker/daterangepicker.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->


<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>
 

<!-- AdminLTE for demo purposes -->

<script>
document.getElementById('file').onchange = function () {
	var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '')

  $("#fileLabel").html(filename);
};


	

	
	

	
  // do something
  $.post("controller.php", {
	
	
	catid : <?php echo $_REQUEST['upid']; ?>,
	action : 'gettest'
	
	
}, function(result) {
	
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['Patient_Name'].length; i++) {
		
		
		
		


		$("#patientname").val(fres['Patient_Name'][i]);
		$("#Pfather").val(fres['Father_Name'][i]);
		$("#gender").val(fres['gender'][i]).change();
		$("#age").val(fres['Age'][i]);
		$("#mydate").val(fres['Date'][i]);
		$("#adminname").val(fres['Lab_Incharge'][i]);
		$("#Incharge_ID").val(fres['Incharge_ID'][i]);
		
		
		$("#getdoctor").val(fres['Doctor'][i]).change();
		$("#gettesttype").val(fres['TestType'][i]).change();
		$("#fileLabel").html(fres['picture'][i]);
		$("#picture").val(fres['picture'][i]);
		doctor=fres['Doctor'][i];
		testtype=fres['TestType'][i];
		
		
	}

	
	
});

function FetchData() {
		var doctor =$("#getdoctor").val();
		var test =$("#gettesttype").val();
		var docresult = doctor.split(' ').join('')
		var result = test.split(' ').join('')
		
  		document.getElementById("doctor").value = docresult;
		document.getElementById("category").value = result;

}
setTimeout(FetchData, 100);
 

function updatetest() {	


		
		$.post("controller.php", {
			
			tid : <?php echo $_REQUEST['upid']; ?>,
			patientname : $("#patientname").val(),
			Pfather : $("#Pfather").val(),
			gender : $("#gender :selected").text(),
			age : $("#age").val(),
			mydate : $("#mydate").val(),
			Lab_Incharge : $("#adminname").val(),
			Incharge_ID : $("#Incharge_ID").val(),
			doctor : $("#doctor :selected").text(),
			category : $("#category :selected").text(),
			
			
			action : 'updatetest'
			
		}, function(result) {
			
	var filevalue =	document.getElementById('fileLabel').textContent;
	var picvalue =	document.getElementById('picture').value;	
	
	if(filevalue==picvalue)
	{
	
		alert(filevalue);
	}
	else
	{
		
	
	
  var input = document.getElementById("file");
  file = input.files[0];
  if(file != undefined){
    formData= new FormData();
    if(!!file.type.match(/image.*/)){
		$.post("controller.php", {
	picname : document.getElementById('picture').value	,
	action : 'deletepic'
	
}, function(result) {
	

	
	
		
	
	
});
		
      formData.append("image", file);
	  formData.append("itemid", result);
      $.ajax({
        url: "uploadtestpic.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(data){
            
        }
      });
    }else{
      alert('Not a valid image!');
    }
  }else{
  }		
			
			

					swal({
  title: "Success",
  text: " Test updated Successfully",
  icon: "success",
 
   showConfirmButton:false,
  confirmButtonText: 'Ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		
window.location.href = "AddTest.php";		

	  
 
  } 
});
				
		}	
		});
			
		
	}


$.post("controller.php", {
	adminid : <?php echo $_SESSION['adminid']; ?>,
	action : 'getadminname'
	
}, function(result) {
	

	
	var categories = jQuery.parseJSON(result);
	
	for (var i = 0; i < categories['adminid'].length; i++) {
		
		document.getElementById('adminname').value= categories['Name'][i]   ;
		document.getElementById('Incharge_ID').value= categories['adminid'][i]   ;
		
	}
	
});


$.post("controller.php", {
	
	action : 'getcategories'
	
}, function(result) {
	
	$("#category").html('');
	
	$("#category").append('<option value=0 selected disabled></option>');
	
	var categories = jQuery.parseJSON(result);
	
	for (var i = 0; i < categories['TestType'].length; i++) {
		var cats=categories['TestType'][i];
		var result = cats.split(' ').join('')
		
		
		
		$("#category").append('<option value='+result+'>' + categories['TestType'][i] + '</option>');
	
	}
	
});

$.post("controller.php", {
	
	action : 'getdoctors'
	
}, function(result) {
	
	$("#doctor").html('');
	
	$("#doctor").append('<option value=0 selected disabled></option>');
	
	var categories = jQuery.parseJSON(result);
	
	for (var i = 0; i < categories['Name'].length; i++) {
		var cats=categories['Name'][i];
		var result = cats.split(' ').join('')
		
		
		$("#doctor").append('<option value='+result+'>' + categories['Name'][i] + '</option>');
	
	}
	
});
var dateObj = new Date();
var month = dateObj.getUTCMonth() + 1; //months from 1-12
var day = dateObj.getUTCDate();
var year = dateObj.getUTCFullYear();

newdate = month + "/" + day + "/" + year;
document.getElementById("mydate").value = newdate;




	
	
	





	
	

</script>





</body>
</html>

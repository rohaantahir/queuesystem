<?php

include ('model.php');

$dir = "testimages/";

session_start();

$picname = $_SESSION['pid'].".";

$picname .= rand(1000, 9999);

$picname .= ".jpg";

move_uploaded_file($_FILES["image"]["tmp_name"], $dir. $picname);

$addobj = new ModalOperations();

$addobj -> updatepatientpic($_SESSION['pid'], $picname);


?>
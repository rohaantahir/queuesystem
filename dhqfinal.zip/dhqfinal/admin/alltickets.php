<?php

require $_SERVER['DOCUMENT_ROOT'] . '/dhq/sidebars/' . 'sidebar_viewtickets.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>All Tickets</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">

  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/jquery.dataTables.min.css">
   <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/sweetalert.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
 
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>


  <!-- iCheck -->

  <!-- Google Font: Source Sans Pro -->
</head>
<body class="hold-transition sidebar-mini" >
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">THQ</span>
    </a>

    <!-- Sidebar -->

	<?php echo pagesidebar($dept); ?>
	
    <!-- /.sidebar -->
  </aside>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <section class="content">
    <!-- Content Header (Page header) -->
    		<div class="row">
	
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-info collapsed-card">
              <div class="card-header">
                <h3 class="card-title">Generate Ticket</h3>
				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">
				
				

				  

				  
				 
				 
				  
				  
                <div class="row">
				  <div class="col-md-3">
				  
                    <label for="exampleInputEmail1">Starting Number<b style="color:red;">*</b> </label>
                    <input type="number" class="form-control" id="from" style="text-transform: capitalize;" placeholder="From"/>
					<input type="hidden" class="form-control" id="adminname" placeholder="Enter Patient's Name"/>
					<input type="hidden" class="form-control" id="Incharge_ID" placeholder="Enter Patient's Name"/>
					
				  </div>
				  <div class="col-md-3">
				  
                    <label for="exampleInputEmail1">Ending Number<b style="color:red;">*</b></label>
                    <input type="number" class="form-control" id="to"  style="text-transform: capitalize;" placeholder="To">
					
				  </div>
				  <div class="col-md-6">
				  <div class="row">
				  <div class="col-md-6">
                   <div class="form-group">
                    <label>Ticket Type</label>
                    <select class="form-control" id="type">
                      <option value="X-Ray">X-Ray</option>
                      <option value="Ultrasound">Ultrasound</option>
                   
                    </select>
                  </div>
				  
				  </div>
				
				  </div >
				  
				 
				  
					
				  </div>
				
				
				 
				  
			  
				  

                </div>
				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="inesertData();" class="btn btn-info">Submit</button>			  
				  
                </div>
            
            </div>


          </div>	
		  
		  </div>
    <!-- /.content-header -->
	
		 
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">All Generated Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
              <table id="example1" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                       <th tabIndex="-1" >Start </th>
					  <th tabIndex="-1">End</th>
					  <th tabIndex="-1">Total</th>
					  <th tabIndex="-1">Date</th>
					  <th tabIndex="-1">type</th>
					  <th tabIndex="-1">action</th>



                    </tr>
                </thead>
                 <tbody id="alltickets">

                 </tbody>
               
              </table>
            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          		  
	  
		  
	
	
    <!-- Main content -->
   
</section>

  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Developed by Technodez <a href="http://technodez.com/">Technodez</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $dept; ?>plugins/chartjs-old/Chart.min.js"></script>
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/jquery-ui.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>



<script src="<?php echo $dept; ?>dist/js/jquery.dataTables.min.js"></script>

<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<script>

	




function inesertData() {
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;

	var from = $("#from").val();
	var to =  $("#to").val();
	if(to <= from)
	{
	alert(from + ' is not equal to or less than '  +to +'  please enter valid value ');
	//alert(to);
	}
	else if ($("#from").val() == "" || $("#to").val() == "")
	{
		alert("Please fill all fields")
	}
	else
	{
		total = to-from 
				$.post("controller.php", {
			
			
			from : from,
			to : to,
			total : total,
			date : today,
			type : $("#type :selected").text(),

			action : 'generateTickets'
			
		}, function(result) {

			$.post("controller.php", {
			
			
			from : from,
			to : to,
			total : total,
			date : today,
			type : $("#type :selected").text(),

			action : 'generatedailytickets'
			
		}, function(result) {

			swal({
  title: "Success",
  text: "Tickets Generated Successfully",
  icon: "success",
 
   showConfirmButton:false,
  confirmButtonText: 'Ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		
location.reload();		

	  
 
  } 
});
	

	
			
			
			
		});
	

	
			
			
			
		});
	}
	
}
$.post("controller.php", {
	
	
	action : 'gettickets'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {



                    var temp = '<tr >';
                    
					  
                      temp +='<td style="height: px;">'+fres['start'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['end'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['total'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['date'][i]+'</td>';
					   temp +='<td style="height: px;">'+fres['type'][i]+'</td>';
					  temp +='<td style="height: 10px;"><button onclick="deletetocken('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';

					  

                    temp +='</tr>';	
		
		  $('#alltickets').append(temp);
		  

	
		
	}	
	
$('#example1').DataTable( {} );	


	
});	
function deletetocken(delid)
{
	
swal({
  title: "Are you sure?",
  text: "Delete Item permanently",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  $.post("controller.php", {
	
	delid : delid,
	
	action : 'deleteticket'
	
}, function(result) {
		
	location.reload();
});		

	  
 
  } 
});
	


}
    


</script>


</body>
</html>

<?php

include ('model.php');


if (isset($_REQUEST['action'])) {

	if ($_REQUEST['action'] == 'generateTickets') {
		$addobj = new ModalOperations();
		
		$dres = $addobj -> deleteallticket();

		$id = $addobj -> addnewticket($_REQUEST['from'], $_REQUEST['to'], $_REQUEST['total']+1, $_REQUEST['date'], $_REQUEST['type']);
		
		echo $id;
		
		session_start();
		
		$_SESSION['itemid'] = $id;
		
	}
	if ($_REQUEST['action'] == 'gettopgenerated') {
		$dobj = new ModalOperations();
		
		$itemsarr = "";
		
		$campres = $dobj -> gettoprowgenerated();
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr= $row['id'];
			

		}

		}
		
		echo json_encode($itemsarr);
		
	}

	if ($_REQUEST['action'] == 'generatedailytickets') {
		$addobj = new ModalOperations();
		
		$itemsarr = "";
		$tno ="";
		
		$campres = $addobj -> gettoprowgenerated();
		$results = $addobj -> gettoprowgeneratedaily($_REQUEST['type']);
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr= $row['id'];
			
			

		}

		}
		if ($results -> num_rows > 0) {

		while ($row = $results -> fetch_assoc()) {
			
			$tno= $row['ticketno'];
			
			

		}

		}
		echo $itemsarr;
		if($tno != "")
		{
			echo $tno;
			$tno = substr($tno, 3);
			echo "\n" .$tno;
			$tno++;
			$start = $tno;
			echo "new line is ";
			echo $start;
		}
		else
		{
			$start = $_REQUEST['from'];
		}
		$total = $_REQUEST['total']+1;

		$type = $_REQUEST['type'];
		$semistr = "";
		if ($type == "X-Ray")
		{
			$semistr = " X-";
		}
		else if ($type == "Ultrasound")
		{
			$semistr = " U-";
		}
		for ($i = 1; $i <= $total ; $i++)
		{
			if( $start <=100)
			{
				$tempid =  $semistr . $start ;
			}
			else if ( $start >=100)
			{
				$tempid =  $semistr . $start ;
			}
			$start++;
			$status = 'Un Attended';
			echo $tempid ;
			

			$id = $addobj -> addbatchticket($tempid, $status, $_REQUEST['type'], $_REQUEST['date'],$itemsarr);
		}
		echo $id;
		
		
		
	}

	
	
	
	
	if ($_REQUEST['action'] == 'gettickets') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> getitems();
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['id'][] = $row['id'];
			$itemsarr['start'][] = $row['start'];
			$itemsarr['end'][] = $row['end'];
			$itemsarr['date'][] = $row['date'];
			$itemsarr['type'][] = $row['type'];
			$itemsarr['total'][] = $row['total'];

		}

		}
		
		echo json_encode($itemsarr);
		
	}
	
	if ($_REQUEST['action'] == 'getdailytickets') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> getfreshtokens($_REQUEST['date']);
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['id'][] = $row['id'];
			$itemsarr['status'][] = $row['status'];
			$itemsarr['type'][] = $row['type'];
			$itemsarr['ticketno'][] = $row['ticketno'];

			$itemsarr['date'][] = $row['date'];

		}

		}
		
		echo json_encode($itemsarr);
		
	}
		if ($_REQUEST['action'] == 'getdailyactivetickets') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> getallactive();
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['id'][] = $row['id'];
			$itemsarr['status'][] = $row['status'];
			$itemsarr['type'][] = $row['type'];
			$itemsarr['ticketno'][] = $row['ticketno'];

			$itemsarr['date'][] = $row['date'];

		}

		}
		
		echo json_encode($itemsarr);
		
	}
	if ($_REQUEST['action'] == 'gettoprowxray') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> gettoprowxray();
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['id'][] = $row['id'];
			$itemsarr['status'][] = $row['status'];
			$itemsarr['type'][] = $row['type'];
			$itemsarr['ticketno'][] = $row['ticketno'];

			$itemsarr['date'][] = $row['date'];

		}

		}
		
		echo json_encode($itemsarr);
		
	}		
	if ($_REQUEST['action'] == 'gettoprowusound') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> gettoprowusound();
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['id'][] = $row['id'];
			$itemsarr['status'][] = $row['status'];
			$itemsarr['type'][] = $row['type'];
			$itemsarr['ticketno'][] = $row['ticketno'];

			$itemsarr['date'][] = $row['date'];

		}

		}
		
		echo json_encode($itemsarr);
		
	}		
		
	
	
	
	
	
	if ($_REQUEST['action'] == 'deleteticket') {
		
		$dobj = new ModalOperations();
		
		
		$dres = $dobj -> deleteitem($_REQUEST['delid']);
		
	}	
	if ($_REQUEST['action'] == 'deleteoneticket') {
		
		$dobj = new ModalOperations();
		
		
		$dres = $dobj -> deleteoneticket($_REQUEST['delid']);
	}	
	
	if ($_REQUEST['action'] == 'changestatus') {
		
		$dobj = new ModalOperations();
		
		echo "adasd";
		
		$dres = $dobj -> changestatus($_REQUEST['id'],$_REQUEST['newstate']);
		echo $_REQUEST['newstate'];
		echo "dasasdas";
	}	
	
	
	
	if ($_REQUEST['action'] == 'getitemdetails') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> getitemdetails($_REQUEST['itemid']);
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['itemid'][] = $row['itemid'];
			$itemsarr['itemname'][] = $row['itemname'];
			$itemsarr['itemquantity'][] = $row['itemquantity'];
			$itemsarr['itemprice'][] = $row['itemprice'];
			$itemsarr['itemdescription'][] = $row['itemdescription'];
			$itemsarr['pic'][] = $row['pic'];

		}

		}
		
		echo json_encode($itemsarr);
		
	}		
	
	
	if ($_REQUEST['action'] == 'updatedata') {
		$addobj = new ModalOperations();
		
		$addobj -> updateitem($_REQUEST['itemid'], $_REQUEST['itemname'], $_REQUEST['itemquantity'], $_REQUEST['itemprice'], $_REQUEST['itemdescription']);
		
		session_start();
		
		$_SESSION['itemid'] = $_REQUEST['itemid'];
		$_SESSION['itempic'] = $_REQUEST['itempic'];
		
	}	
	
	
		if ($_REQUEST['action'] == 'getactivexray') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> getactivexray();
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['id'][] = $row['id'];
			

		}

		}
		
		echo json_encode($itemsarr);
		
	}
	if ($_REQUEST['action'] == 'getactiveusound') {
		
		$dobj = new ModalOperations();
		
		$itemsarr = array();
		
		$campres = $dobj -> getactiveusound();
		
		if ($campres -> num_rows > 0) {

		while ($row = $campres -> fetch_assoc()) {
			
			$itemsarr['id'][] = $row['id'];
			

		}

		}
		
		echo json_encode($itemsarr);
		
	}
	







}
?>
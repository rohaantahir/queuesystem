<?php

require $_SERVER['DOCUMENT_ROOT'] . '/dhq/sidebars/' . 'sidebar_generate.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Generate Tickets</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
   <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/sweetalert.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->

  
  <!-- Google Font: Source Sans Pro -->
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>

 <link rel="stylesheet" href="../viewerjs-master/dist/viewer.css">
  <!-- Font Awesome -->
  
  <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css"/>
  <!-- Google Font: Source Sans Pro -->
 
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>


  <!-- iCheck -->

  <!-- Google Font: Source Sans Pro -->
</head>
<style>
.blinking{
	animation:blinkingText 2s infinite;
}
@keyframes blinkingText{
	0%{		color: red;	}
	
	50%{	color: black;	}
	
	100%{	color: red;	}
}
</style>
<body class="hold-transition sidebar-mini"  onload = "">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">THQ</span>
    </a>

    <!-- Sidebar -->

	<?php echo pagesidebar($dept); ?>
	
    <!-- /.sidebar -->
  </aside>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <section class="content">
    <!-- Content Header (Page header) -->
    		    		<div class="row">
	
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Generate Ticket</h3>
				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">
				
				

				  

				  
				 
				 
				  
				  
                <div class="row">
				  <div class="col-md-3"style="display:none;">
				  
                    <label for="exampleInputEmail1">Starting Number<b style="color:red;">*</b> </label>
                    <input type="hidden" class="form-control" id="from" style="text-transform: capitalize;" value=1  placeholder="From" />
					<input type="hidden" class="form-control" id="adminname" placeholder="Enter Patient's Name"/>
					<input type="hidden" class="form-control" id="Incharge_ID" placeholder="Enter Patient's Name"/>
					<input type="hidden" class="form-control" id="ticketnumber" placeholder="Enter Patient's Name"/>
						<input type="hidden" class="form-control" id="roomtype" placeholder="Enter Patient's Name"/>
					
				  </div>
				  <div class="col-md-3">
				  
                    <label for="exampleInputEmail1">Ending Number<b style="color:red;">*</b></label>
                    <input type="number" class="form-control" id="to"  style="text-transform: capitalize;" placeholder="To">
					
				  </div>
				  <div class="col-md-6">
				  <div class="row">
				  <div class="col-md-6">
                   <div class="form-group">
                    <label>Ticket Type</label>
                    <select class="form-control" id="type">
                      <option value="X-Ray">X-Ray</option>
                      <option value="Ultrasound">Ultrasound</option>
                   
                    </select>
                  </div>
				  
				  </div>
				
				  </div >
				  
				 
				  
					
				  </div>
				
				
				 
				  
			  
				  

                </div>
				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="inesertData();" class="btn btn-info">Submit</button>			  
				  
                </div>
            
            </div>


          </div>	
		  
		  </div>
				  

				  
	
    <!-- /.content-header -->
	
		  <div class="row" tabIndex="-1">
		  
          <div class="col-md-6" tabIndex="-1">
		   <div class="alert alert-info alert-dismissible" id="xray-card" style="display:none;">
                  <h2 class="blinking" id="xraycall"><i class="icon fa fa-ban"></i></h2>
                </div>
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card collapsed-card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">X-Ray Active Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
				
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
			 <div >
			                 <button onclick="callnextxray();" class="btn btn-info float-right">Call Next</button>
							    <button onclick="callxray();" class="btn btn-default float-left">Call Again</button> 

							   
			<br/>

						   

			 </div>
			 <br/>	
              <table id="example1" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                       <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="x-ray">

                 </tbody>
               
              </table>
            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		            <div class="col-md-6" tabIndex="-1">
					 <div class="alert alert-info alert-dismissible"  id ="usound-card" style="display:none;">
                  <h2  class="blinking" id="usoundcall"><i class="icon fa fa-ban"></i></h2>
                </div>
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card collapsed-card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">Ultrasound Active Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
			
			 <div >
			                  <button onclick="callnextUsound();" class="btn btn-info float-right"> Call Next</button> 

							   
							   <button onclick="callUsound();" class="btn btn-default float-left">Call Again</button> 

							   
			<br/>

						   

			 </div>
			 

			 <br/>	
              <table id="example2" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                      <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="Ultrasound">

                 </tbody>
               
              </table>

            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		  
		  </div>
	
		
		  <div class="row" tabIndex="-1">
          <div class="col-md-6" tabIndex="-1">
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card collapsed-card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">X-Ray Inactive Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
              <table id="example3" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                       <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="x-ray_inactive">

                 </tbody>
               
              </table>
            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		            <div class="col-md-6" tabIndex="-1">
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card collapsed-card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">Ultrasound Inactive Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
              <table id="example4" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                      <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="Ultrasound_inactive">

                 </tbody>
               
              </table>

            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>	
		  
		  
		  </div>
    <!-- Main content -->
   
</section>



  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Developed by Technodez <a href="http://technodez.com/">Technodez</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

<script type="text/javascript" src="../DataTables/datatables.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/dataTables.buttons.min.js"></script>

<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="<?php echo $dept; ?>dist/js/moment.min.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../viewerjs-master/dist/viewer.js"></script>
<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>
<script>

function FetchData() {
		
$("#example1").dataTable().fnDestroy();
$("#example2").dataTable().fnDestroy();
$("#example3").dataTable().fnDestroy();		
$("#example4").dataTable().fnDestroy();		

$('#x-ray').empty();
$('#x-ray_inactive').empty();
$('#Ultrasound').empty();
$('#Ultrasound_inactive').empty();
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;		




$.post("controller.php", {

	
	
	action : 'getdailytickets',
	date : today
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);
	
	
	for (var i = 0; i < fres['id'].length; i++) {

				var xrayactive ="";
				var Ultrasoundactive = "";
				 var xrayinactive = "";

				var Ultrasoundinactive = "";

			if(fres['type'][i] == 'X-Ray' && fres['status'][i]=='Un Attended')
				{
				

					temp =1;
					tnum = fres['ticketno'][i].substring(3);;
						xrayactive = '<tr >';
                      xrayactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   xrayactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  xrayactive +='<td style="height: 10px;"><button onclick="xrayalonchange('+fres['id'][i]+','+temp+','+tnum+');" type="button" title="Change to Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    xrayactive +='</tr>';	
				}
				else if (fres['type'][i] == 'Ultrasound' && fres['status'][i]=='Un Attended')
				{
                    temp = 1;
					tnum = fres['ticketno'][i].substring(3);;
					//alert(tnum);
					Ultrasoundactive = '<tr >';
                      Ultrasoundactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   Ultrasoundactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  Ultrasoundactive +='<td style="height: 10px;"><button onclick="usoundalonchange('+fres['id'][i]+','+temp+','+tnum+');" type="button" title="Change to Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    Ultrasoundactive +='</tr>';	
					
				}
				else if (fres['type'][i] == 'X-Ray' && fres['status'][i]=='Attended')
				{
                     temp = 0;

					xrayinactive = '<tr >';
                      xrayinactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   xrayinactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  xrayinactive +='<td style="height: 10px;"><button onclick="change('+fres['id'][i]+','+temp+');" type="button" title="Change to Un Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    xrayinactive +='</tr>';	
					
				}
				else if (fres['type'][i] == 'Ultrasound' && fres['status'][i]== 'Attended')
				{
                    temp = 0;
						Ultrasoundinactive = '<tr >';
                      Ultrasoundinactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   Ultrasoundinactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  Ultrasoundinactive +='<td style="height: 10px;"><button onclick="change('+fres['id'][i]+','+temp+');" type="button" title="Change to Un Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    Ultrasoundinactive +='</tr>';	
					
				}
		   $('#x-ray').append(xrayactive);
		  $('#x-ray_inactive').append(xrayinactive);
		  $('#Ultrasound').append(Ultrasoundactive);
		  $('#Ultrasound_inactive').append(Ultrasoundinactive);



	
		
	}
	

	
$(document).ready(function() {
    $('#example2').DataTable( {
       
      
	"ordering": false,
	
    } );
} );	
	
$(document).ready(function() {
    $('#example1').DataTable( {
      
      
	"ordering": false,
	
    } );
} );	
$(document).ready(function() {
    $('#example3').DataTable( {
      
      
	"ordering": false,
	
    } );
} );	$(document).ready(function() {
    $('#example4').DataTable( {
      
      
	"ordering": false,
	
    } );
} );	
	
});	
	
}setTimeout(FetchData,100);


function calltocken(number,type)
{

if(type =='Ultrasound')
{	
var numlength = number.length;
var strings =4;
var index = 1;
var check = numlength;
//alert(check);
if(check == 1)
{
	//alert("check1");
	
	//alert("check2");
	var audio = new Audio();
	audio.src='./voices2/sound.mp3';
	audio.play();

	audio.onended = function() {
    if(index == 1){
        audio.src='./voices2/start-u1.m4a';
        audio.play();
        index++;
    }
	else if(index == 2){
        audio.src='./voices2/'+number[0]+'.m4a';
        audio.play();
        index++;
    }
	
	else if(index == 3){
        audio.src='./voices2/end-u.m4a';
        audio.play();
        index++;
    }
	};
}
else if(check == 2)
{
	//alert("check2");
	var audio = new Audio();
	audio.src='./voices2/sound.mp3';
	audio.play();

	audio.onended = function() {
    if(index == 1){
        audio.src='./voices2/start-u1.m4a';
        audio.play();
        index++;
    }
	else if(index == 2){
        audio.src='./voices2/'+number+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 3){
        audio.src='./voices2/end-u.m4a';
        audio.play();
        index++;
    }
	
	};
}
else if(check == 3)
{
	//alert("check2");
	var audio = new Audio();
	audio.src='./voices2/sound.mp3';
	audio.play();

	audio.onended = function() {
    if(index == 1){
        audio.src='./voices2/start-u1.m4a';
        audio.play();
        index++;
    }
	else if(index == 2){
        audio.src='./voices2/'+number[0]+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 3){
        audio.src='./voices2/'+number[1]+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 4){
        audio.src='./voices2/'+number[2]+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 5){
        audio.src='./voices2/end-u.m4a';
        audio.play();
        index++;
    }
	
	};
}


}
else if (type == 'X-Ray')
{
var numlength = number.length;
var strings =4;
var index = 1;
var check = numlength;
//alert(check);
if(check == 1)
{
	//alert("check1");
	
	//alert("check2");
	var audio = new Audio();
	audio.src='./voices2/sound.mp3';
	audio.play();

	audio.onended = function() {
    if(index == 1){
        audio.src='./voices2/start-x.m4a';
        audio.play();
        index++;
    }
	else if(index == 2){
        audio.src='./voices2/'+number[0]+'.m4a';
        audio.play();
        index++;
    }
	
	else if(index == 3){
        audio.src='./voices2/end-x.m4a';
        audio.play();
        index++;
    }
	};
}
else if(check == 2)
{
	//alert("check2");
	var audio = new Audio();
	audio.src='./voices2/sound.mp3';
	audio.play();

	audio.onended = function() {
    if(index == 1){
        audio.src='./voices2/start-x.m4a';
        audio.play();
        index++;
    }
	else if(index == 2){
        audio.src='./voices2/'+number+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 3){
        audio.src='./voices2/end-x.m4a';
        audio.play();
        index++;
    }
	
	};
}
else if(check == 3)
{
	//alert("check2");
	var audio = new Audio();
	audio.src='./voices2/sound.mp3';
	audio.play();

	audio.onended = function() {
    if(index == 1){
        audio.src='./voices2/start-x.m4a';
        audio.play();
        index++;
    }
	else if(index == 2){
        audio.src='./voices2/'+number[0]+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 3){
        audio.src='./voices2/'+number[1]+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 4){
        audio.src='./voices2/'+number[2]+'.m4a';
        audio.play();
        index++;
    }
	else if(index == 5){
        audio.src='./voices2/end-x.m4a';
        audio.play();
        index++;
    }
	
	};
}
}
}



function check()
{
	$('#myTable').DataTable().clear().destroy();

}
	
function changestatus1(id,status)
{
	alert(id);
	alert(status);
}	


function callnextxray()
{
	
		$.post("controller.php", {
	
	
	action : 'gettoprowxray'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {
			speechtext='Ticket Number '+fres['ticketno'][i]+' kindly proceed to '+fres['type'][i]+' room';
			writetext='Ticket# '+fres['ticketno'][i]+' to '+fres['type'][i]+' Room';
			document.getElementById("ticketnumber").value = fres['ticketno'][i];
			document.getElementById("roomtype").value = fres['type'][i];
			$("#xraycall").text(writetext);
			//$('#example1').dataTable().fnClearTable();
			$("#xray-card").show()
			//speak(speechtext);
			
			//$('#example1').dataTable().fnClearTable();
			number = fres['ticketno'][i].substring(3);
			
			calltocken(number,'X-Ray');
			changestatus(fres['id'][i],1);
			FetchData();

		
	}	

});		
}
function callxray()
{
	
	

 ticketno =  document.getElementById("ticketnumber").value;
 type = document.getElementById("roomtype").value;

if (ticketno == "")
{
	alert("kindly call someone first");
}
else 
{
	
			writetext='Ticket# '+ticketno+' to '+type+' Room';

			number = ticketno.substring(3);
			
			calltocken(number,'X-Ray');
			//speak(speechtext);
			
			//$('#example1').dataTable().fnClearTable();
			$("#xray-card").show()

			$("#xraycall").text(writetext);
			
			

}	

			

	
}
function callUsound()
{
	

 ticketno =  document.getElementById("ticketnumber").value;
 type = document.getElementById("roomtype").value;

if (ticketno == "")
{
	alert("kindly call someone first");
}
else 
{
	
			writetext='Ticket# '+ticketno+' to '+type+' Room';

			number = ticketno.substring(3);
			
			calltocken(number,'Ultrasound');
			//speak(speechtext);
			
				$("#usound-card").show()

			$("#usoundcall").text(writetext);			
			
			//$('#example1').dataTable().fnClearTable();
			
			

}	

	
	
			
			

	
}
function callnextUsound()
{
			
$.post("controller.php", {
	
	
	action : 'gettoprowusound'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {
			speechtext='Ticket Number '+fres['ticketno'][i]+' kindly proceed to '+fres['type'][i]+' room';
			writetext='Ticket# '+fres['ticketno'][i]+' to '+fres['type'][i]+' Room';
			//speak(speechtext);
			$("#xraycall").text(writetext);
			document.getElementById("ticketnumber").value = fres['ticketno'][i];
			document.getElementById("roomtype").value = fres['type'][i];
			number = fres['ticketno'][i].substring(3);
			
			calltocken(number,'Ultrasound');
	$("#usoundcall").text(writetext);
			$("#usound-card").show()

			

			
			//var audiostart = new Audio('./voices/start.mp3');
	



			//setTimeout(function(){/* Look mah! No name! */ new Audio('./voices/start.mp3').play();},0);
			

			changestatus(fres['id'][i],1);
			FetchData();

	}	

});		
	
}


function deleteticket(delid)
{
	
swal({
  title: "Are you sure?",
  text: "Delete Item permanently",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  $.post("controller.php", {
	
	delid : delid,
	
	action : 'deleteoneticket'
	
}, function(result) {
		
	location.reload();
});		

	  
 
  } 
});
	


}
function changestatus(id ,status)
{
	newstate = ""
	if (status == 1)
	{
		newstate = "Attended";
		}
	else {
		newstate = "Un Attended";

	}
		
	$.post("controller.php", {
	
	id : id,
	newstate: newstate,
	
	action : 'changestatus'
	
}, function(result) {
		
	//location.reload();
});		
}
function usoundalonchange(id ,status,tnum)
{
	
	
	mystr = " U-" + tnum;

	speechtext='Ticket number '+mystr+' kindly proceed to Ultrasound Room';
	writetext ='Ticket# '+mystr+' to Ultrasound Room';
	document.getElementById("ticketnumber").value = mystr;
	document.getElementById("type").value = "Ultrasound";
	number = mystr.substring(3);
			
	calltocken(number,'Ultrasound');
	
	$("#usoundcall").text(writetext);
	$("#usound-card").show()

	changestatus(id,1);
	FetchData();
	
}
function xrayalonchange(id ,status,tnum)
{
	
	mystr = " X-" + tnum;

	speechtext='Ticket number '+mystr+' kindly proceed to X-Ray Room';
	writetext ='Ticket# '+mystr+' to X-Ray Room';
	document.getElementById("ticketnumber").value = mystr;
	document.getElementById("type").value = "X-Ray";
	number = mystr.substring(3);
		calltocken(number,'X-Ray');

	$("#xraycall").text(writetext);
	changestatus(id,1);
	$("#xray-card").show()

	FetchData();
	
}
function change(id ,status)
{

	newstate = ""
	if (status == 1)
	{
		newstate = "Attended";
		}
	else {
		newstate = "Un Attended";

	}
		
	$.post("controller.php", {
	
	id : id,
	newstate: newstate,
	
	action : 'changestatus'
	
}, function(result) {
	
		FetchData();

		
});		
}




function inesertData() {
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;

	var from = $("#from").val();
	var to =  $("#to").val();
	if(to < from)
	{
	alert(from + ' is not equal to or less than '  +to +'  please enter valid value ');
	//alert(to);
	}
	else if ($("#from").val() == "" || $("#to").val() == "")
	{
		alert("Please fill all fields")
	}
	else
	{
		total = to-from 
				$.post("controller.php", {
			
			
			from : from,
			to : to,
			total : total,
			date : today,
			type : $("#type :selected").text(),

			action : 'generateTickets'
			
		}, function(result) {

			$.post("controller.php", {
			
			
			from : from,
			to : to,
			total : total,
			date : today,
			type : $("#type :selected").text(),
			action : 'generatedailytickets'

			
		}, function(result) {

			swal({
  title: "Success",
  text: "Tickets Generated Successfully",
  icon: "success",
 
   showConfirmButton:false,
  confirmButtonText: 'Ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		
location.reload();		

	  
 
  } 
});
	

	
			
			
			
		});
	

	
			
			
			
		});
	}
	
}



</script>


</body>
</html>

<?php

require $_SERVER['DOCUMENT_ROOT'] . '/dhq/sidebars/' . 'sidebar_generate.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Main Menu</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
   <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/sweetalert.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->

  
  <!-- Google Font: Source Sans Pro -->
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>

 <link rel="stylesheet" href="../viewerjs-master/dist/viewer.css">
  <!-- Font Awesome -->
  
  <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css"/>
  <!-- Google Font: Source Sans Pro -->
 
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>


  <!-- iCheck -->

  <!-- Google Font: Source Sans Pro -->
</head>
<style>
.blinking{
	animation:blinkingText 2s infinite;
}
@keyframes blinkingText{
	0%{		color: white;	}
	
	50%{	color: black;	}
	
	100%{	color: white;	}
}
</style>
<body class="hold-transition sidebar-mini"  onload = "get_all_tokens();">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">DHQ</span>
    </a>

    <!-- Sidebar -->

	<?php echo pagesidebar($dept); ?>
	
    <!-- /.sidebar -->
  </aside>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <section class="content">
    <!-- Content Header (Page header) -->
    		<div class="row">
	
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Generate Ticket</h3>
				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
      
                <div class="card-body">
				
				

				  

				  
				 
				 
				  
				  
                <div class="row">
				  <div class="col-md-3">
				  
                    <label for="exampleInputEmail1">Starting Number<b style="color:red;">*</b> </label>
                    <input type="number" class="form-control" id="from" style="text-transform: capitalize;" placeholder="From"/>
					<input type="hidden" class="form-control" id="adminname" placeholder="Enter Patient's Name"/>
					<input type="hidden" class="form-control" id="Incharge_ID" placeholder="Enter Patient's Name"/>
					
				  </div>
				  <div class="col-md-3">
				  
                    <label for="exampleInputEmail1">Ending Number<b style="color:red;">*</b></label>
                    <input type="number" class="form-control" id="to"  style="text-transform: capitalize;" placeholder="To">
					
				  </div>
				  <div class="col-md-6">
				  <div class="row">
				  <div class="col-md-6">
                   <div class="form-group">
                    <label>Ticket Type</label>
                    <select class="form-control" id="type">
                      <option value="X-Ray">X-Ray</option>
                      <option value="Ultrasound">Ultrasound</option>
                   
                    </select>
                  </div>
				  
				  </div>
				
				  </div >
				  
				 
				  
					
				  </div>
				
				
				 
				  
			  
				  

                </div>
				
			 
				  
				

				  
				  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button onclick="inesertData();" class="btn btn-info">Submit</button>			  
				  
                </div>
            
            </div>


          </div>	
		  
		  </div>
    <!-- /.content-header -->
	
		  <div class="row" tabIndex="-1">
		  
          <div class="col-md-6" tabIndex="-1">
		   <div class="alert alert-info alert-dismissible">
                  <h2 class="blinking" id="xraycall"><i class="icon fa fa-ban"></i></h2>
                </div>
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">X-Ray Active Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
				
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
			 <div >
			                   <button onclick="callnextxray();" class="btn btn-info float-right">Call Next</button>
							    <button onclick="callxray();" class="btn btn-default float-left">Call Again</button>

							   
			<br/>

						   

			 </div>
			 <br/>	
              <table id="example1" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                       <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="x-ray">

                 </tbody>
               
              </table>
            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		            <div class="col-md-6" tabIndex="-1">
					 <div class="alert alert-info alert-dismissible">
                  <h2  class="blinking" id="usoundcall"><i class="icon fa fa-ban"></i></h2>
                </div>
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">Ultrasound Active Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
			
			 <div >
			                   <button onclick="callnextUsound();" class="btn btn-info float-right"> Next</button>

							   
							   <button onclick="callUsound();" class="btn btn-default float-left">Call Again</button>

							   
			<br/>

						   

			 </div>
			 

			 <br/>	
              <table id="example2" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                      <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="Ultrasound">

                 </tbody>
               
              </table>

            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		  
		  </div>
	
		
		  <div class="row" tabIndex="-1">
          <div class="col-md-6" tabIndex="-1">
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">X-Ray Inactive Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
              <table id="example3" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                       <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="x-ray_inactive">

                 </tbody>
               
              </table>
            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>		  
		            <div class="col-md-6" tabIndex="-1">
            <!-- general form elements -->
            <div class="card card-info" tabIndex="-1">
             
				    <div class="card" tabIndex="-1">
            <div class="card-header">
              <h3 class="card-title">Ultrasound Inactive Tickets</h3>
			  				<div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                 
                </div>
            </div>
			
            <!-- /.card-header -->
            <div class="card-body" >
              <table id="example4" class="table table-bordered table-striped" tabIndex="-1">
                <thead >
               <tr >
                      
                      <th tabIndex="-1" >Ticket # </th>
					  <th tabIndex="-1">Status</th>
					  <th tabIndex="-1">Action</th>
					  
                    </tr>
                </thead>
                 <tbody id="Ultrasound_inactive">

                 </tbody>
               
              </table>

            </div>
            <!-- /.card-body -->
          </div>
                <!-- /.card-body -->
            
            </div>


          </div>	
		  
		  
		  </div>
    <!-- Main content -->
   
</section>

	<form class="container text-center"> 
		<div class="row" style="display:none;"> 
			<div class="col-sm-6 mx-auto"> 
				<div class="form-group"> 
					<div id="front-text" class="text-success"> 
						GeeksforGeeks Text-to-Speech Conversion 
					</div> 
					
					<!-- Input box text area -->
					<textarea id="maintext" class="form-control form-control-lg"
						style="max-lines: 2" placeholder="Enter the text..."> 
					</textarea> 
				</div> 
			</div> 
		</div> 
		
		<!-- Rate of voice which we will be updated by user -->
		<div class="row" style="display:none;"> 
			<div class="col-sm-6 mx-auto"> 
				<div class="form-group"> 
					<label for="rate">Rate</label> 
					<div id="rate-value" class="badge badge-primary" >5</div> 
					<input class="custom-range" type="range" id="rate" max="1"
						min="0.2" value="0.5" step="0.1"> 
				</div> 
			</div> 
		</div> 
		
		<!-- Pitch of voice which we will be updated by user -->
		<div class="row" style="display:none;"> 
			<div class="col-sm-6 mx-auto"> 
				<div class="form-group"> 
					<label for="pitch">Pitch</label> 
					<div id="pitch-value" class="badge badge-primary" >5</div> 
					<input class="custom-range" type="range" id="pitch" max="1"
						min="0.2" value="0.5" step="0.1"> 
				</div> 
			</div> 
		</div> 
		
		<!-- The different types of voice along with country and language -->
		<div class="row" > 
			<div class="col-sm-6 mx-auto"> 
				<div class="form-group" style=""> 
					
					<!-- This section will be dynamically loaded from 
						the API so we left it blank for now-->
					<select class="form-control form-control-lg"
							id="voice-select" ></select>				 
				</div> 
				
				<!-- Button to enable the speech from the 
					text given in the input box -->
				<button id="submit" class="btn btn-success btn-lg" onclick="speak();"> 
					Speak it 
				</button> 
			</div> 
		</div> 
	</form> 

  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Developed by Technodez <a href="http://technodez.com/">Technodez</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $dept; ?>plugins/chartjs-old/Chart.min.js"></script>
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/jquery-ui.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>



<script src="<?php echo $dept; ?>dist/js/jquery.dataTables.min.js"></script>

<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<script>
function FetchData() {
		
$("#example1").dataTable().fnDestroy();
$("#example2").dataTable().fnDestroy();
$("#example3").dataTable().fnDestroy();		
$("#example4").dataTable().fnDestroy();		

$('#x-ray').empty();
$('#x-ray_inactive').empty();
$('#Ultrasound').empty();
$('#Ultrasound_inactive').empty();
		




$.post("controller.php", {

	
	
	action : 'getdailytickets'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);
	
	
	for (var i = 0; i < fres['id'].length; i++) {

				var xrayactive ="";
				var Ultrasoundactive = "";
				 var xrayinactive = "";

				var Ultrasoundinactive = "";

			if(fres['type'][i] == 'X-Ray' && fres['status'][i]=='Un Attended')
				{
				

					temp =1;
					tnum = fres['ticketno'][i].substring(3);;
						xrayactive = '<tr >';
                      xrayactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   xrayactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  xrayactive +='<td style="height: 10px;"><button onclick="xrayalonchange('+fres['id'][i]+','+temp+','+tnum+');" type="button" title="Change to Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    xrayactive +='</tr>';	
				}
				else if (fres['type'][i] == 'Ultrasound' && fres['status'][i]=='Un Attended')
				{
                    temp = 1;
					tnum = fres['ticketno'][i].substring(3);;
					//alert(tnum);
					Ultrasoundactive = '<tr >';
                      Ultrasoundactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   Ultrasoundactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  Ultrasoundactive +='<td style="height: 10px;"><button onclick="usoundalonchange('+fres['id'][i]+','+temp+','+tnum+');" type="button" title="Change to Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    Ultrasoundactive +='</tr>';	
					
				}
				else if (fres['type'][i] == 'X-Ray' && fres['status'][i]=='Attended')
				{
                     temp = 0;

					xrayinactive = '<tr >';
                      xrayinactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   xrayinactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  xrayinactive +='<td style="height: 10px;"><button onclick="change('+fres['id'][i]+','+temp+');" type="button" title="Change to Un Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    xrayinactive +='</tr>';	
					
				}
				else if (fres['type'][i] == 'Ultrasound' && fres['status'][i]== 'Attended')
				{
                    temp = 0;
						Ultrasoundinactive = '<tr >';
                      Ultrasoundinactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   Ultrasoundinactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  Ultrasoundinactive +='<td style="height: 10px;"><button onclick="change('+fres['id'][i]+','+temp+');" type="button" title="Change to Un Attended" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    Ultrasoundinactive +='</tr>';	
					
				}
		   $('#x-ray').append(xrayactive);
		  $('#x-ray_inactive').append(xrayinactive);
		  $('#Ultrasound').append(Ultrasoundactive);
		  $('#Ultrasound_inactive').append(Ultrasoundinactive);



	
		
	}
	

	
$(document).ready(function() {
    $('#example2').DataTable( {
       
      
	"ordering": true,
	"columnDefs": [{
        "targets": [1]
    }]
    } );
} );	
	
$(document).ready(function() {
    $('#example1').DataTable( {
      
      
	"ordering": true,
	"columnDefs": [{
        "targets": [1],
    }]
    } );
} );	
$(document).ready(function() {
    $('#example3').DataTable( {
      
      
	"ordering": true,
	"columnDefs": [{
        "targets": [1],
    }]
    } );
} );	$(document).ready(function() {
    $('#example4').DataTable( {
      
      
	"ordering": true,
	"columnDefs": [{
        "targets": [1],
    }]
    } );
} );	
	
});	
	
}setTimeout(FetchData,100);

function callit(){
}
// Initialising the speech API 
const synth = window.speechSynthesis; 

// Element initialization section 
const form = document.querySelector('form'); 
const textarea = "Ticket number 50 please proceed to X-Ray Room"; 
const voice_select = document.getElementById('voice-select'); 
const rate = document.getElementById('rate'); 
const pitch = document.getElementById('pitch'); 
// Retrieving the different voices and putting them as 
// options in our speech selection section 
let voices = []; 
const getVoice = () => { 
	
	// This method retrieves voices and is asynchronously loaded 
	voices = synth.getVoices(); 
	var option_string = ""; 
	voices.forEach(value => { 
		var option = value.name + ' (' + value.lang + ') '; 
		var newOption = "<option data-name='" + value.name + 
				"' data-lang='" + value.lang + "'>" + option 
				+ "</option>\n"; 
		option_string += newOption; 
	}); 
	
	voice_select.innerHTML = option_string; 
} 

// Since synth.getVoices() is loaded asynchronously, this 
// event gets fired when the return object of that 
// function has changed 
synth.onvoiceschanged = function() { 
	getVoice(); 
}; 

const speak = (text) => { 
	// If the speech mode is on we dont want to load 
	// another speech 
	if(synth.speaking) { 
		alert('Already speaking....'); 
		return; 
	} 
	
	// If the text area is not empty that is if the input 
	// is not empty 
	if(text !== '') { 
		
		// Creating an object of SpeechSynthesisUtterance with 
		// the input value that represents a speech request 
		const speakText = new SpeechSynthesisUtterance(text); 

		// When the speaking is ended this method is fired 
		speakText.onend = e => { 
			console.log('Speaking is done!'); 
		}; 
		
		// When any error occurs this method is fired 
		speakText.error = e=> { 
			console.error('Error occured...'); 
		}; 

		// Selecting the voice for the speech from the selection DOM 
		const id = voice_select.selectedIndex; 
		const selectedVoice = 
			voice_select.selectedOptions[0].getAttribute('data-name'); 
	
		// Checking which voices has been chosen from the selection 
		// and setting the voice to the chosen voice 
		voices.forEach(voice => { 
			if(voice.name === selectedVoice) { 
				speakText.voice = voice; 
			} 
		}); 

		// Setting the rate and pitch of the voice 
		speakText.rate = rate.value; 
		speakText.pitch = pitch.value; 

		// Finally calling the speech function that enables speech 
		synth.speak(speakText); 
	} 
}; 

// This function updates the rate and pitch value to the 
// value to display 
rate.addEventListener('change', evt => rateval.innerHTML 
		= (Number.parseFloat(rate.value) * 10) + ""); 

pitch.addEventListener('change', evt => pitchval.innerHTML 
		= (Number.parseFloat(pitch.value) * 10) + ""); 

// This is the section when we assign the speak button, the 
// speech function 

	 
	


function callnextxray()
{
	$.post("controller.php", {
	
	
	action : 'gettoprowxray'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {
			speechtext='Ticket Number '+fres['ticketno'][i]+' Kindly proceed to '+fres['type'][i]+' room';

			speak(speechtext);
		
	}	

});		
	
}

function callnextUsound()
{
	$.post("controller.php", {
	
	
	action : 'gettoprowusound'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {
			speechtext='Ticket Number '+fres['ticketno'][i]+' Kindly proceed to '+fres['type'][i]+' room';
			speak(speechtext);
		
	}	

});		
	
}
function get_all_tokens()
{
		
	
	
$.post("controller.php", {
	
	
	action : 'getdailytickets'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);

	
	for (var i = 0; i < fres['id'].length; i++) {

                var xrayactive = '<tr >';
				var Ultrasoundactive = '<tr >';
				var xrayinactive = '<tr >';
				var Ultrasoundinactive = '<tr >';

				if(fres['type'][i] == 'X-Ray' && fres['status'][i]=='Un Attended')
				{
                    
					temp =1;

                      xrayactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   xrayactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  xrayactive +='<td style="height: 10px;"><button onclick="changestatus('+fres['id'][i]+','+temp+');" type="button" title="Update Category" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    xrayactive +='</tr>';	
				}
				else if (fres['type'][i] == 'Ultrasound' && fres['status'][i]=='Un Attended')
				{
                    temp = 1;

					  
                      Ultrasoundactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   Ultrasoundactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  Ultrasoundactive +='<td style="height: 10px;"><button onclick="changestatus('+fres['id'][i]+','+temp+');" type="button" title="Update Category" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    Ultrasoundactive +='</tr>';	
					
				}
				else if (fres['type'][i] == 'X-Ray' && fres['status'][i]=='Attended')
				{
                     temp = 0;

					  
                      xrayinactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   xrayinactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  xrayinactive +='<td style="height: 10px;"><button onclick="changestatus('+fres['id'][i]+','+temp+');" type="button" title="Update Category" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    xrayinactive +='</tr>';	
					
				}
				else if (fres['type'][i] == 'Ultrasound' && fres['status'][i]== 'Attended')
				{
                    temp = 0;
					  
                      Ultrasoundinactive +='<td style="height: px;">'+fres['ticketno'][i]+'</td>';
					   Ultrasoundinactive +='<td style="height: px;">'+fres['status'][i]+'</td>';
					  
					   
					  Ultrasoundinactive +='<td style="height: 10px;"><button onclick="changestatus('+fres['id'][i]+','+temp+');" type="button" title="Update Category" class="btn btn-sm btn-info "><i class="fa fa-refresh"></i></button>   <button onclick="deleteticket('+fres['id'][i]+');" type="button" title="Delete Category" class="btn btn-sm btn-info "><i class="fa fa-trash"></i></button></td>';
					  
					
					  

                    Ultrasoundinactive +='</tr>';	
					
				}
		
		  $('#x-ray').append(xrayactive);
		  $('#x-ray_inactive').append(xrayinactive);
		  $('#Ultrasound').append(Ultrasoundactive);
		  $('#Ultrasound_inactive').append(Ultrasoundinactive);


	
		
	}	
	
$('#example2').DataTable( {} );	


	
});	
}

function deleteticket(delid)
{
	
swal({
  title: "Are you sure?",
  text: "Delete Item permanently",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {

  $.post("controller.php", {
	
	delid : delid,
	
	action : 'deleteoneticket'
	
}, function(result) {
		
	location.reload();
});		

	  
 
  } 
});
	


}


function changestatus(id ,status)
{
	newstate = ""
	if (status == 1)
	{
		newstate = "Attended";
		alert("sadasd")
		}
	else {
		newstate = "Un Attended";
		alert(newstate)

	}
		
	$.post("controller.php", {
	
	id : id,
	newstate: newstate,
	
	action : 'changestatus'
	
}, function(result) {
		
	location.reload();
});		
}




function inesertData() {
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;

	var from = $("#from").val();
	var to =  $("#to").val();
	if(to <= from)
	{
	alert(from + ' is not equal to or less than '  +to +'  please enter valid value ');
	//alert(to);
	}
	else if ($("#from").val() == "" || $("#to").val() == "")
	{
		alert("Please fill all fields")
	}
	else
	{
		total = to-from 
				$.post("controller.php", {
			
			
			from : from,
			to : to,
			total : total,
			date : today,
			type : $("#type :selected").text(),

			action : 'generateTickets'
			
		}, function(result) {

			$.post("controller.php", {
			
			
			from : from,
			to : to,
			total : total,
			date : today,
			type : $("#type :selected").text(),

			action : 'generatedailytickets'
			
		}, function(result) {

			swal({
  title: "Success",
  text: "Tickets Generated Successfully",
  icon: "success",
 
   showConfirmButton:false,
  confirmButtonText: 'Ok!',

  dangerMode: false,
})
.then((willDelete) => {
  if (willDelete) {

 
		
location.reload();		

	  
 
  } 
});
	

	
			
			
			
		});
	

	
			
			
			
		});
	}
	
}


    


</script>


</body>
</html>

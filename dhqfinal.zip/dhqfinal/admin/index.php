<?php

require $_SERVER['DOCUMENT_ROOT'] . '/dhq/sidebars/' . 'adminsidebarandheader.php';

$dept = "../";

if (!isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'login/');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Main Menu</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">

  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/jquery.dataTables.min.css">
   <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/sweetalert.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
 
  
  <!-- Google Font: Source Sans Pro -->
 <script src="<?php echo $dept; ?>dist/js/jquery.min.js"></script>


  <!-- iCheck -->

  <!-- Google Font: Source Sans Pro -->
</head>
<body class="hold-transition sidebar-mini" onload="onload();">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo pageheader($dept); ?>
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="<?php echo $dept; ?>images/hospital.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">THQ</span>
    </a>

    <!-- Sidebar -->

	<?php echo pagesidebar($dept); ?>
	
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Tehsil Head Quarter Hospital Jaranwala</h1>
          </div><!-- /.col -->
		  
		  
				

        </div><!-- /.row -->
		
		
				
		
		
      </div><!-- /.container-fluid -->	  
	  
	  
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
	<div class="row" style="margin-left:10px;">
	     <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3 id="today"></h3>

                <p>Unattended X-Ray Tickets</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="dailytickets.php" class="small-box-footer"> More <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3 id="totoal"></h3>

                <p>Unattended Ultrasound Tickets</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="dailytickets.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
		  <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3 id="doctors"></h3>

                <p>Total Unattended Tickets</p>
              </div>
              <div class="icon">
                <i class="ion ion-person"></i>
              </div>
              <a href="dailytickets.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
	</div>
	<div class="col-md-10">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
       <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Tickets Chart</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="pieChart" style="height:100px"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
        <!-- /.row -->
        <!-- Main row -->
        
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Developed by Technodez <a href="http://technodez.com/">Technodez</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo $dept; ?>plugins/chartjs-old/Chart.min.js"></script>
<script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/jquery-ui.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/sweetalert.min.js"></script>



<script src="<?php echo $dept; ?>dist/js/jquery.dataTables.min.js"></script>

<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/adminlte.js"></script>
<script src="../viewerjs-master/dist/viewer.js"></script>
<script>
function onload()
{
	
var datestr = $('#reservation').val();
var dateObj = new Date();
var month = dateObj.getUTCMonth() + 1; //months from 1-12
var day = dateObj.getUTCDate();
var year = dateObj.getUTCFullYear();

newdate = month + "/" + day + "/" + year;



var xray = 0;
var usound = 0;
var totals = 0;
$.post("controller.php", {


	action : 'getactivexray'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);
	
	
	for (var i = 0; i < fres['id'].length; i++) {

				xray++;

                  
		
		

	
		
	}
	
	

	
});	
$.post("controller.php", {

	
	
	
	action : 'getactiveusound'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);
	
	
	for (var i = 0; i < fres['id'].length; i++) {

				usound++;

                  
		
		

	
		
	}
	

	
});	
$.post("controller.php", {

	
	
	
	action : 'getdailyactivetickets'
	
}, function(result) {
	
	var fres = jQuery.parseJSON(result);
	
	
	for (var i = 0; i < fres['id'].length; i++) {

				totals++;

                  
		
		

	
		
	}
	
	//alert(totals);

	
});

function FetchData() {
	var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieChart       = new Chart(pieChartCanvas)
    var PieData        = [
      {
        value    : xray,
        color    : '#f56954',
        highlight: '#f56954',
        label    : 'Unattended X-Ray'
      },
      
      {
        value    : usound,
        color    : '#d2d6de',
        highlight: '#d2d6de',
        label    : 'Unattended Ultrasound'
      }
    ]
    var pieOptions     = {
      //Boolean - Whether we should show a stroke on each segment
      segmentShowStroke    : true,
      //String - The colour of each segment stroke
      segmentStrokeColor   : '#fff',
      //Number - The width of each segment stroke
      segmentStrokeWidth   : 2,
      //Number - The percentage of the chart that we cut out of the middle
      percentageInnerCutout: 50, // This is 0 for Pie charts
      //Number - Amount of animation steps
      animationSteps       : 100,
      //String - Animation easing effect
      animationEasing      : 'easeOutBounce',
      //Boolean - Whether we animate the rotation of the Doughnut
      animateRotate        : true,
      //Boolean - Whether we animate scaling the Doughnut from the centre
      animateScale         : false,
      //Boolean - whether to make the chart responsive to window resizing
      responsive           : true,
      // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio  : true,
      //String - A legend template
      legendTemplate       : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    pieChart.Doughnut(PieData, pieOptions)

		
document.getElementById("today").innerHTML = xray;
document.getElementById("totoal").innerHTML = usound;
document.getElementById("doctors").innerHTML = totals;

}
setTimeout(FetchData, 500);





}

    


</script>


</body>
</html>

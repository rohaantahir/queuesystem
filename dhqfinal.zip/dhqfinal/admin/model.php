<?php

class ModalOperations {

	public function addnewticket($from, $to, $total, $date, $type) {
		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);
		// Check connection
		if ($conn -> connect_error) {
			echo "sdada";
			return null;
		}
		
		//$tags = "hello";
		
		
		// prepare and bind
		$stmt = $conn -> prepare("INSERT INTO `tickets`(`start`, `end`, `total`, `date`, `type`) VALUES (?,?,?,?,?)");
		$stmt -> bind_param("sssss", $from, $to, $total, $date, $type);
		$stmt -> execute();

		$id = $conn -> insert_id;
		$stmt -> close();
		$conn -> close();
		return $id;
	}	
	
		public function addbatchticket($ticketno, $status, $type, $date,$gid) {
		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);
		// Check connection
		if ($conn -> connect_error) {
			echo "sdada";
			return null;
		}
		
		//$tags = "hello";
		
		
		// prepare and bind
		$stmt = $conn -> prepare("INSERT INTO `dailytickets`(`ticketno`, `status`, `type`, `date`,`gid`) VALUES (?,?,?,?,?)");
		$stmt -> bind_param("sssss", $ticketno, $status, $type, $date,$gid);
		$stmt -> execute();

		$id = $conn -> insert_id;
		$stmt -> close();
		$conn -> close();
		return $id;
	}	
	
	

	
	
	
	public function getitems() {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `tickets`";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}
	public function getfreshtokens($date) {
		

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		//where `date`= '$date'
		$sql = "SELECT * From `dailytickets`";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}
	public function getactivexray() {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `dailytickets` where `type` = 'X-Ray' and `status` = 'Un Attended' ";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}
		public function getallactive() {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `dailytickets` where `status` = 'Un Attended' ";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}
	public function getactiveusound() {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `dailytickets` where `type` = 'Ultrasound' and `status` = 'Un Attended' ";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}	
		public function gettoprowxray() {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `dailytickets`  where `type` = 'X-Ray' and `status` = 'Un Attended' order by `id`  limit 1 ";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}
		public function gettoprowusound() {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `dailytickets`  where `type` = 'Ultrasound' and `status` = 'Un Attended'  order by `id`  limit 1 ";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}	
	public function gettoprowgenerated() {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `tickets` order by `id` desc limit 1 ";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}
	public function gettoprowgeneratedaily($type) {
		echo $type;
		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `dailytickets` where `type` = '$type' order by `id` desc limit 1 ";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}	
	public function deleteitem($itemid) {
		// Create connection
		
		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);
		// Check connection
		if ($conn -> connect_error) {
			return null;
		}
		
		$sql = "Delete From `tickets` where `id` = '$itemid'";
		$sql2 = "Delete From `dailytickets` where `gid` = '$itemid'";

		$result = $conn -> query($sql);
		$result2 = $conn -> query($sql2);

		$conn -> close();
		return $result;
	}	
		public function deleteoneticket($itemid) {
		// Create connection
		
		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);
		// Check connection
		if ($conn -> connect_error) {
			return null;
		}
		
		$sql = "Delete From `dailytickets` where `id` = '$itemid'";
		$result = $conn -> query($sql);
		$conn -> close();
		return $result;
	}	
		public function deleteallticket() {
		// Create connection
		
		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);
		// Check connection
		if ($conn -> connect_error) {
			return null;
		}
		
		$sql = "Delete From `dailytickets` where `status` = 'Attended'";
		$result = $conn -> query($sql);
		$conn -> close();
		return $result;
	}	
	

	public function getadmindetails($adminid) {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		
		$sql = "SELECT * From `admin` where `adminid` = '$adminid'";
		$result = $conn -> query($sql);
		
		$conn -> close();
		return $result;
	}		
	
	public function updateadmin($adminid, $adminname, $adminemail, $adminpassword, $number) {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/Hospital/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}	
		
		$sql = "UPDATE `admin` SET  `User_Name`='$adminname', `Name`='$adminemail', `Password`='$adminpassword', `Number`='$number' WHERE `adminid`='$adminid'"; 
		
		$result = $conn -> query($sql);
		
		$conn -> close();
	}	
	public function changestatus($id, $newstate) {

		$config = parse_ini_file($_SERVER["DOCUMENT_ROOT"] . '/dhq/' . 'config.ini');
		// Create connection
		$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);	
	
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}	
		
		$sql = "UPDATE `dailytickets` SET  `status`='$newstate' WHERE `id`='$id'"; 
		
		$result = $conn -> query($sql);
		
		$conn -> close();
	}	
	
	
	

}


?>
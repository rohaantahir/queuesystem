<?php

include ('model.php');

session_start();

function pageheader($dept)
{


?>

  <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>


    </ul>

    <!-- SEARCH FORM -->


    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->

      <!-- Notifications Dropdown Menu -->

      <li class="nav-item">
        <a title="Logout" class="nav-link" href="<?php echo $dept; ?>logout"><i
            class="fa fa-sign-out fa-2x"></i></a>
      </li>
    </ul>
  </nav>



<?php


}

function pagesidebar($dept)
{
	
	
$dobj = new ModalOperations();

$adminname = "";

$campres = $dobj -> getadmindetails($_SESSION['adminid']);

if ($campres -> num_rows > 0) {

while ($row = $campres -> fetch_assoc()) {
	
	$adminname = $row['name'];

}

}	

?>


    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo $dept; ?>admin/image/user.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $adminname; ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

		  <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class=""></i>
              <p>
                Labs
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              
			 <li class="nav-item has-treeview menu-open">
            <a href="" class="nav-link active">
              <i class="nav-icon fa fa-pie-chart"></i>
              <p>
                X-Ray Lab
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo $dept; ?>admin/itemcategory.php" class="nav-link">
                  <i class="fa fa-plus nav-icon"></i>
                  <p>ADD Test</p>
                </a>
              </li>
            </ul>
			<ul class="nav nav-treeview" style="margin-right:20px;">
              <li class="nav-item">
                <a href="pages/charts/chartjs.html" class="nav-link">
                  <i class="fa fa-eye nav-icon"></i>
                  <p>View Test</p>
                </a>
              </li>
            </ul>
			<ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="pages/charts/chartjs.html" class="nav-link">
                  <i class="fa fa-refresh -o nav-icon"></i>
                  <p>Update Test</p>
                </a>
              </li>
            </ul>
          </li>
            </ul>
          </li>
		  
		  
          
		  
          <li class="nav-item">
            <a href="<?php echo $dept; ?>admin/itemcategory.php" class="nav-link">
              <i class="nav-icon fa fa-th"></i>
              <p>
                Item Categories
              </p>
            </a>
          </li>			  

          <li class="nav-item">
            <a href="<?php echo $dept; ?>admin/reports.php" class="nav-link">
              <i class="nav-icon fa fa-th"></i>
              <p>
                Reports
              </p>
            </a>
          </li>	

          <li class="nav-item">
            <a href="<?php echo $dept; ?>admin/addserviceboy.php" class="nav-link">
              <i class="nav-icon fa fa-th"></i>
              <p>
                Add Service Boy
              </p>
            </a>
          </li>	

          <li class="nav-item">
            <a href="<?php echo $dept; ?>admin/allserviceboys.php" class="nav-link">
              <i class="nav-icon fa fa-th"></i>
              <p>
                Show Service Boys
              </p>
            </a>
          </li>			  

          <li class="nav-item">
            <a href="<?php echo $dept; ?>admin/updateadmin.php" class="nav-link">
              <i class="nav-icon fa fa-th"></i>
              <p>
                Settings
              </p>
            </a>
          </li>	

          <li class="nav-item">
            <a href="<?php echo $dept; ?>logout/" class="nav-link">
              <i class="nav-icon fa fa-th"></i>
              <p>
                Logout
              </p>
            </a>
          </li>			  








        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>










<?php

}

?>
<?php
 header("Location: logout/index.php");
$dept = "";

?>
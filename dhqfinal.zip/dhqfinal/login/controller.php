<?php
include('login.php');
$dept = "../";
$controller = new Login();
if (isset($_REQUEST['action'])) {

	if ($_REQUEST['action'] == 'checkuser') {
		$result = $controller -> doLogin($_REQUEST['username'],$_REQUEST['password']);
		
		
		if ($result -> num_rows > 0) {
		
			while ($row = $result -> fetch_assoc()) {
				$adminid = $row["adminid"];
			}
			
			session_start();
			$_SESSION['adminid'] = $adminid;
	
			echo "yes";
			
			 
			
}
		else {
			
			echo "no";
			
		}
	}
	
}

?>

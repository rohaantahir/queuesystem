<?php

$dept = "../";
session_start();

if (isset($_SESSION['adminid'])) {

	header('Location: ' . $dept . 'admin/index.php');
}


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="images/hospitalicon.ico" />
  <title>Admin Login | Log in</title>
  
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $dept; ?>dist/css/adminlte.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo $dept; ?>plugins/iCheck/square/blue.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="<?php echo $dept; ?>dist/css/googlefont.css" rel="stylesheet">
</head>
<style>
body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("hospital.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
<body class="hold-transition login-page bg" >
<div class="login-box">
  
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
	<div class="login-logo">
  <img src="../images/hospital.png" alt="logo" height="42" width="42"/>
      <a href="#" tabIndex="-1"> <b> THQ Jaranwala </b> </a>

   
  </div>
  <div class="login-logo">
  
       Auto Ticketing System <p style="text-align:center;">Admin Login</p>

   
  </div>
	
     

        <div class="form-group has-feedback">
          <input type="email"  id="username" class="form-control"  placeholder="User Name">
         
        </div>
        <div class="form-group has-feedback">
          <input type="password" id="password" class="form-control" placeholder="Password">
          
        </div>
        <div class="row">
          <div class="col-8">
            <div class="checkbox icheck">
             
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4" >
            <button onclick="doLogin();" class="btn btn-info">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
   

      <!-- /.social-auth-links -->

      
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->

  <script src="<?php echo $dept; ?>plugins/jquery/jquery.min.js"></script>
<script src="<?php echo $dept; ?>dist/js/jquery-ui.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo $dept; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- iCheck -->
<script src="<?php echo $dept; ?>plugins/iCheck/icheck.min.js"></script>
<script>
$(function() {
  $("#username").focus();
});
document.onkeydown=function(evt){
        var keyCode = evt ? (evt.which ? evt.which : evt.keyCode) : event.keyCode;
        if(keyCode == 13)
        {
           doLogin();
        }
    }


  	function doLogin()
  	{
		
  		$.post("controller.php", {
			action : "checkuser",
			username : $("#username").val(),
			password : $("#password").val()
		}, function(notice) {
			

			
			if(notice=='yes')
				location.href = '../admin';
			else
			
			alert("Wrong Credentials");
		

		});
		
	
		
  	}
  
  
</script>
</body>
</html>

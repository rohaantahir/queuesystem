<?php
class Login {
	var $config;
	function __construct() {
		$this -> config = parse_ini_file($_SERVER['DOCUMENT_ROOT'] . '/Hospital/' . 'config.ini');
	}

	public function doLogin($username,$pass) {
		// Create connection
		$conn = new mysqli($this->config['servername'], $this->config['username'], $this->config['password'], $this->config['dbname']);
		// Check connection
		if ($conn -> connect_error) {
			return FALSE;
		}
		
		$sql = "SELECT * FROM `admin` WHERE User_Name='".$username."' AND Password='".$pass."'";
		$result = $conn -> query($sql);
		
	
		$conn -> close();
		return $result;
	}

}
?>
